import pytest

from .. import core

def test_thingy():
    assert 1 == 1
